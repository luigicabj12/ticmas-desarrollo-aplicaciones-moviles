package com.ticmas.luisluna.proyectofinal.model

data class DataModel(
    val text1: String,
    val text2: String,
    val tvResult: String
)